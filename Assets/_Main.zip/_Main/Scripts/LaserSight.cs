﻿using UnityEngine;

public class LaserSight : MonoBehaviour
{
    [SerializeField] private LineRenderer laserLineRenderer;
    [SerializeField] private Transform laserStartPoint;
    [SerializeField] private LayerMask laserHitLayerMask;


    private void Start() 
    {
        laserLineRenderer.SetPosition(0, laserStartPoint.localPosition);
    }

    private void Update() 
    {
        if (Physics.Raycast(laserStartPoint.position, laserStartPoint.forward, out RaycastHit hit, 100.0f, laserHitLayerMask))
        {
            SetLaserPoints(new Vector3(0, 0, hit.distance));
            //SetLaserPoints(laserStartPoint.localPosition + laserStartPoint.forward * 100.0f);
        }
        else
        {
            //SetLaserPoints(laserStartPoint.localPosition + laserStartPoint.forward * 100.0f);
            SetLaserPoints(new Vector3(0, 0, 100.0f));
        }
    }

    private void SetLaserPoints(Vector3 position)
    {
        laserLineRenderer.SetPosition(1, position);
    }
}
