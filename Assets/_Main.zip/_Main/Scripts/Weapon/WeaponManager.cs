﻿using System;
using UnityEngine;

public class WeaponManager : MonoBehaviour
{
    public static event Action<WeaponData> OnAnyWeaponChanged;


    [SerializeField] private GameObject bulletPrefab;
    [SerializeField] private WeaponData[] weaponDataArray;
    [SerializeField] private Weapon[] weaponArray;

    private Transform bulletSpawnPoint;
    private int currentWeaponDataIndex;
    private PlayerControls controls;
    private bool inCooldown;
    private bool canShoot = true;
    private float cooldownTimer;


    private void Awake() 
    {
        controls = new PlayerControls();

        controls.Gameplay.Shoot.performed += context => Shoot();

        controls.Gameplay.ChangeWeapon.performed += context => ChangeWeapon();
    }

    private void Start() 
    {
        if (weaponDataArray.Length <= 0)
        {
            Debug.LogError("There is no weapon to use!");
            return;
        }

        ChangeWeapon(0);
    }

    private void Update() 
    {
        if (inCooldown)
        {
            cooldownTimer -= Time.deltaTime;

            if (cooldownTimer <= 0)
            {
                inCooldown = false;
            }
        }
    }

    private void Shoot()
    {
        if (inCooldown || !canShoot) return;

        //Debug.Log("Shoot");
        cooldownTimer = GetCurrentWeaponData().shootRate;
        GetCurrentWeapon().weaponSound.Play();
        inCooldown = true;

        SpawnBullet();
    }

    private void SpawnBullet()
    {
        Bullet bullet = Instantiate(bulletPrefab, bulletSpawnPoint.position, Quaternion.identity).GetComponent<Bullet>();
        bullet.transform.forward = bulletSpawnPoint.forward;
        bullet.SetBulletDamage(GetCurrentWeaponData().damage);
    }

    private void ChangeWeapon()
    {
        if (currentWeaponDataIndex >= weaponDataArray.Length - 1)
        {
            currentWeaponDataIndex = 0;
        }
        else
        {
            currentWeaponDataIndex++;
        }

        OnAnyWeaponChanged?.Invoke(GetCurrentWeaponData());
        ChangeWeaponMesh();
    }

    private void ChangeWeapon(int index)
    {
        currentWeaponDataIndex = index;

        OnAnyWeaponChanged?.Invoke(GetCurrentWeaponData());
        ChangeWeaponMesh();
    }

    private void ChangeWeaponMesh()
    {
        if (weaponArray.Length <= 0)
        {
            Debug.LogError("No weapon found in Weapon Array! " + transform);
            return;
        }

        for (int i = 0; i < weaponArray.Length; i++)
        {
            weaponArray[i].weaponObject.SetActive(false);
        }

        bool weaponFound = false;

        foreach (Weapon weapon in weaponArray)
        {
            if (weapon.weaponName == GetCurrentWeaponData().weaponName)
            {
                weapon.weaponObject.SetActive(true);
                bulletSpawnPoint = weapon.bulletSpawnPoint;
                weaponFound = true;
            }
        }

        if (!weaponFound)
        {
            Debug.LogError("Couldn't found a weapon named " + GetCurrentWeaponData().weaponName + " in Weapon Array! " + transform);
            return;
        }
    }

    private void OnEnable()
    {
        controls.Gameplay.Enable();

        PlayerSpawner.OnAnySpawnStarted += PlayerSpawner_OnAnySpawnStarted;
        PlayerSpawner.OnAnySpawnCompleted += PlayerSpawner_OnAnySpawnCompleted;
    }

    private void OnDisable() 
    {
        controls.Gameplay.Disable();

        PlayerSpawner.OnAnySpawnStarted -= PlayerSpawner_OnAnySpawnStarted;
        PlayerSpawner.OnAnySpawnCompleted -= PlayerSpawner_OnAnySpawnCompleted;
    }

    public WeaponData GetCurrentWeaponData()
    {
        return weaponDataArray[currentWeaponDataIndex];
    }

    public Weapon GetCurrentWeapon()
    {
        Weapon currentWeapon = weaponArray[currentWeaponDataIndex];

        foreach (Weapon weapon in weaponArray)
        {
            if (weapon.weaponName == GetCurrentWeaponData().weaponName)
            {
                currentWeapon = weapon;
            }
        }

        return currentWeapon;
    }

    private void DisablePlayerShoot()
    {
        canShoot = false;
    }

    private void EnablePlayerShoot()
    {
        canShoot = true;
    }

    private void PlayerSpawner_OnAnySpawnStarted()
    {
        DisablePlayerShoot();
    }

    private void PlayerSpawner_OnAnySpawnCompleted()
    {
        EnablePlayerShoot();
    }

    [System.Serializable]
    public struct Weapon
    {
        public string weaponName;
        public GameObject weaponObject;
        public Transform bulletSpawnPoint;
        public AudioSource weaponSound;
    }
}
