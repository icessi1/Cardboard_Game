﻿using TMPro;
using UnityEngine;

public class WeaponManagerUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI weaponNameTextMesh;

    private void Start() 
    {
        WeaponManager.OnAnyWeaponChanged += WeaponManager_OnAnyWeaponChanged;
    }

    private void WeaponManager_OnAnyWeaponChanged(WeaponData weaponData)
    {
        ChangeWeaponName(weaponData.weaponName);
    }
    private void ChangeWeaponName(string weaponName)
    {
        weaponNameTextMesh.text = weaponName;
    }
}
