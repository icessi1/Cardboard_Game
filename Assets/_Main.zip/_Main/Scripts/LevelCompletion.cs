﻿using System;
using UnityEngine;

public class LevelCompletion : MonoBehaviour
{
    public static event Action<Team> OnAnyLevelCompleted;


    [SerializeField] private LayerMask collectLayerMask;
    [SerializeField] private Team collectTeam;

    private static bool isLevelCompleted = false;


    private void Start() 
    {
        isLevelCompleted = false;
    }

    private void OnTriggerEnter(Collider other)
    {
        if (isLevelCompleted) return;

        if (!CheckLayerMask(other.gameObject)) return;

        if (!CheckTeam(other.gameObject)) return;

        CompleteLevel();
    }

    private bool CheckLayerMask(GameObject collectedObject)
    {
        if (collectLayerMask.value == (collectLayerMask.value | (1 << collectedObject.layer)))
        {
            return true;
        }

        return false;
    }

    private bool CheckTeam(GameObject collectedObject)
    {
        if (!collectedObject.TryGetComponent(out ITeamManager teamManager))
        {
            Debug.LogError("No Team Manager found in " + collectedObject.name);
            return false;
        }

        if (teamManager.GetTeam() == this.collectTeam)
        {
            return true;
        }

        return false;
    }

    private void CompleteLevel()
    {
        Debug.Log("LEVEL COMPLETED");

        OnAnyLevelCompleted?.Invoke(collectTeam);

        isLevelCompleted = true;
    }

    public Team GetTeam()
    {
        return collectTeam;
    }
}
