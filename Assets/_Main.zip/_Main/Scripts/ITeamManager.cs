﻿public interface ITeamManager
{
    Team GetTeam();
}
